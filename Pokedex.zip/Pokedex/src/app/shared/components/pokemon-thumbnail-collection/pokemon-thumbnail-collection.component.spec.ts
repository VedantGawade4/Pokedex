import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonThumbnailCollectionComponent } from './pokemon-thumbnail-collection.component';

describe('PokemonThumbnailCollectionComponent', () => {
  let component: PokemonThumbnailCollectionComponent;
  let fixture: ComponentFixture<PokemonThumbnailCollectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PokemonThumbnailCollectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PokemonThumbnailCollectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
