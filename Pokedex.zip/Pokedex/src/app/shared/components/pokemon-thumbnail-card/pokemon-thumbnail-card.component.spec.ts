import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonThumbnailCardComponent } from './pokemon-thumbnail-card.component';

describe('PokemonThumbnailCardComponent', () => {
  let component: PokemonThumbnailCardComponent;
  let fixture: ComponentFixture<PokemonThumbnailCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PokemonThumbnailCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PokemonThumbnailCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
